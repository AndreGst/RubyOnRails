class ListProduct < ApplicationRecord
  belongs_to :List
  belongs_to :Product
  validates_presence_of :quantity
end
