class Product < ApplicationRecord
  belongs_to :List
  validates_presence_of :name
  validates_presence_of :value
  validates_numericality_of :value, greater_than: 0, allow_nil: true
end
