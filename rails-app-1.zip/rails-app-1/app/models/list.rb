class List < ApplicationRecord
  has_many :list_products, dependent: :restrict_with_error
  belongs_to :Client
  validates_presence_of :name
  validates_presence_of :client
  validates_uniqueness_of :name scope :name.id
end
